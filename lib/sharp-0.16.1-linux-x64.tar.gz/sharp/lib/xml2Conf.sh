#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/target/lib"
XML2_LIBS="-lxml2 -L/target/lib -lz       -lm "
XML2_INCLUDEDIR="-I/target/include/libxml2"
MODULE_VERSION="xml2-2.9.4"

